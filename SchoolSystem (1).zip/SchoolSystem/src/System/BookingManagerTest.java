package System;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class BookingManagerTest {

    @Test
    void testBookSwimmingLesson() {
        // Create a BookingManager instance
        BookingManager bookingManager = new BookingManager();

       
    }

    @Test
    void testChangeOrCancelBooking() {
        // Create a BookingManager instance
        BookingManager bookingManager = new BookingManager();

      
    }

    @Test
    void testAttendSwimmingLesson() {
        // Create a BookingManager instance
        BookingManager bookingManager = new BookingManager();

       
    }

    @Test
    void testMonthlyLearnerReport() {
        // Create a BookingManager instance
        BookingManager bookingManager = new BookingManager();

      
    }

    @Test
    void testMonthlyCoachReport() {
        // Create a BookingManager instance
        BookingManager bookingManager = new BookingManager();

     
    }

    @Test
    void testRegisterNewLearner() {
        // Create a BookingManager instance
        BookingManager bookingManager = new BookingManager();

     
    }
}

