package System;

import java.util.*;

public class Swimming {
    public static void main(String[] args) {
        BookingManager bookingManager = new BookingManager();
        bookingManager.start();
    }
}

class BookingManager {
    private final Map<String, List<Lesson>> timetable;
    private final Map<String, List<String>> coachToLessonMap;
    private final Map<Integer, List<String>> gradeToLessonMap;
    private final Map<String, Learner> learners;
    private final List<String> coaches;
    private final Scanner scanner;

    private int lessonCounter = 1; // Declare lessonCounter here

    public BookingManager() {
        timetable = new HashMap<>();
        coachToLessonMap = new HashMap<>();
        gradeToLessonMap = new HashMap<>();
        learners = new HashMap<>();
        coaches = new ArrayList<>();
        scanner = new Scanner(System.in);

        initializeTimetable();
        initializeLearners();
    }

    private void initializeTimetable() {
        String[] timeSlotsMondayWednesdayFriday = {"4-5pm", "5-6pm", "6-7pm"};
        String[] timeSlotsSaturday = {"2-3PM", "3-4PM"};
        String[] coaches = {"Max", "John", "Lisa"};
        int[] grades = {1, 2, 3, 4, 5};
        String[] days = {"monday", "wednesday", "friday", "saturday"};

        for (String day : days) {
            List<Lesson> lessons = new ArrayList<>();
            String[] timeSlots = (day.equals("saturday")) ? timeSlotsSaturday : timeSlotsMondayWednesdayFriday;
            for (String timeSlot : timeSlots) {
                for (int grade : grades) {
                    for (String coach : coaches) {
                        Lesson lesson = new Lesson("L" + lessonCounter++, day, timeSlot, coach, grade);
                        lessons.add(lesson);
                        addToMaps(lesson);
                    }
                }
            }
            timetable.put(day, lessons);
        }
    }

    private void addToMaps(Lesson lesson) {
        coachToLessonMap.computeIfAbsent(lesson.getCoach(), k -> new ArrayList<>()).add(lesson.getId());
        gradeToLessonMap.computeIfAbsent(lesson.getGradeLevel(), k -> new ArrayList<>()).add(lesson.getId());
    }

    private void initializeLearners() {
        Learner learner1 = new Learner("Olivia Doe", "Male", 7, "123-456-7890", 1);
        Learner learner2 = new Learner("Sophia Johnson", "Female", 8, "987-654-3210", 2);
        Learner learner3 = new Learner("William Brown", "Male", 6, "555-123-4567", 3);

        learners.put(learner1.getName(), learner1);
        learners.put(learner2.getName(), learner2);
        learners.put(learner3.getName(), learner3);
    }

    public void start() {
        boolean running = true;
        while (running) {
            displayMenu();
            int choice = getIntInput("Enter your choice: ");
            switch (choice) {
                case 1:
                    bookSwimmingLesson();
                    break;
                case 2:
                    changeOrCancelBooking();
                    break;
                case 3:
                    attendSwimmingLesson();
                    break;
                case 4:
                    monthlyLearnerReport();
                    break;
                case 5:
                    monthlyCoachReport();
                    break;
                case 6:
                    registerNewLearner();
                    break;
                case 7:
                    running = false;
                    System.out.println("Exiting. Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 7.");
            }
        }
        scanner.close();
    }

    private void displayMenu() {
        System.out.println("----HATFIELD JUNIOR SWIMMING SCHOOL----");
        System.out.println("1. Book a swimming lesson");
        System.out.println("2. Cancel/Change booking");
        System.out.println("3. Attend the swimming lesson");
        System.out.println("4. Monthly learner report");
        System.out.println("5. Monthly coach report");
        System.out.println("6. Register a new learner");
        System.out.println("7. Exit");
    }

    private int getIntInput(String message) {
        System.out.print(message);
        while (!scanner.hasNextInt()) {
            System.out.print("Invalid input. Please enter a number: ");
            scanner.next();
        }
        int input = scanner.nextInt();
        scanner.nextLine();
        return input;
    }

    private void bookSwimmingLesson() {
        System.out.println("Enter how to view the timetable:");
        System.out.println("1. Using the day");
        System.out.println("2. Using the grade level");
        System.out.println("3. Using the coach's name");
        int choice = getIntInput("Enter your choice: ");

        switch (choice) {
            case 1:
                viewTimetableByDay();
                break;
            case 2:
                viewTimetableByGrade();
                break;
            case 3:
                viewTimetableByCoach();
                break;
            default:
                System.out.println("Invalid choice.");
                break;
        }
    }

    private void viewTimetableByDay() {
        System.out.print("Enter the day (monday, wednesday, friday, saturday): ");
        String day = scanner.nextLine();
        List<Lesson> lessons = timetable.getOrDefault(day.toLowerCase(), new ArrayList<>());

        displayLessons(lessons);

        bookLesson(lessons);
    }

    private void viewTimetableByGrade() {
        int grade = getIntInput("Enter the grade level: ");
        List<String> lessonIds = gradeToLessonMap.getOrDefault(grade, new ArrayList<>());
        List<Lesson> lessons = getLessonsByIds(lessonIds);

        displayLessons(lessons);

        bookLesson(lessons);
    }

    private void viewTimetableByCoach() {
        System.out.print("Enter the name of coach: ");
        String coach = scanner.nextLine();
        List<String> lessonIds = coachToLessonMap.getOrDefault(coach.toLowerCase(), new ArrayList<>());
        List<Lesson> lessons = getLessonsByIds(lessonIds);

        displayLessons(lessons);

        bookLesson(lessons);
    }

    private void displayLessons(List<Lesson> lessons) {
        System.out.println("LESSON ID\tDAY\tTIME\tCOACH\tGRADE");
        for (Lesson lesson : lessons) {
            System.out.println(lesson.getId() + "\t\t" + lesson.getDay() + "\t" +
                    lesson.getTimeSlot() + "\t" + lesson.getCoach() + "\t" +
                    lesson.getGradeLevel());
        }
    }

    private void bookLesson(List<Lesson> lessons) {
        String lessonId = getStringInput("Enter the lesson ID for booking: ");
        Lesson selectedLesson = lessons.stream()
                .filter(lesson -> lesson.getId().equalsIgnoreCase(lessonId))
                .findFirst()
                .orElse(null);

        if (selectedLesson != null) {
            if (selectedLesson.getNumLearners() < 4) {
                String learnerName = getStringInput("Enter the name of learner: ");
                Learner learner = learners.get(learnerName);
                if (learner != null) {
                    if (!learner.getBookedLessons().contains(selectedLesson.getId())) {
                        learner.bookLesson(selectedLesson.getId());
                        selectedLesson.incrementNumLearners();
                        System.out.println("Booking successful for learner " + learnerName + ".");
                    } else {
                        System.out.println("You have already booked the lesson.");
                    }
                } else {
                    System.out.println("Learner not found.");
                }
            } else {
                System.out.println("This lesson is full.");
            }
        } else {
            System.out.println("Invalid lesson ID.");
        }
    }

    private String getStringInput(String message) {
        System.out.print(message);
        return scanner.nextLine();
    }

    private void changeOrCancelBooking() {
        // Implementation of changeOrCancelBooking
    }

    private void attendSwimmingLesson() {
        // Implementation of attendSwimmingLesson
    }

    private void monthlyLearnerReport() {
        // Implementation of monthlyLearnerReport
    }

    private void monthlyCoachReport() {
        // Implementation of monthlyCoachReport
    }

    private void registerNewLearner() {
        // Implementation of registerNewLearner
    }

    private List<Lesson> getLessonsByIds(List<String> lessonIds) {
        List<Lesson> lessons = new ArrayList<>();
        for (List<Lesson> lessonList : timetable.values()) {
            for (Lesson lesson : lessonList) {
                if (lessonIds.contains(lesson.getId())) {
                    lessons.add(lesson);
                }
            }
        }
        return lessons;
    }

    class Lesson {
        private String id;
        private String day;
        private String timeSlot;
        private String coach;
        private int gradeLevel;
        private int numLearners;

        public Lesson(String id, String day, String timeSlot, String coach, int gradeLevel) {
            this.id = id;
            this.day = day;
            this.timeSlot = timeSlot;
            this.coach = coach;
            this.gradeLevel = gradeLevel;
            this.numLearners = 0; // Initialize number of learners
        }

        public String getId() {
            return id;
        }

        public String getDay() {
            return day;
        }

        public String getTimeSlot() {
            return timeSlot;
        }

        public String getCoach() {
            return coach;
        }

        public int getGradeLevel() {
            return gradeLevel;
        }

        public int getNumLearners() {
            return numLearners;
        }

        public void incrementNumLearners() {
            numLearners++;
        }
    }

    class Learner {
        private String name;
        private String gender;
        private int age;
        private String emergencyContact;
        private int gradeLevel;
        private List<String> bookedLessons;

        public Learner(String name, String gender, int age, String emergencyContact, int gradeLevel) {
            this.name = name;
            this.gender = gender;
            this.age = age;
            this.emergencyContact = emergencyContact;
            this.gradeLevel = gradeLevel;
            this.bookedLessons = new ArrayList<>();
        }

        public void bookLesson(String lessonId) {
            bookedLessons.add(lessonId);
        }

        public void cancelBooking(String lessonId) {
            bookedLessons.remove(lessonId);
        }

        public void attendLesson(String lessonId) {
            // Implementation of attendLesson
        }

        public List<String> getBookedLessons() {
            return bookedLessons;
        }

        public String getName() {
            return name;
        }
    }
}
